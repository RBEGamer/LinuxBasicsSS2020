#include <boost/thread/thread.hpp>
#include <MyLibrary.h>



int main()
{
    hello();
    return 0;
}