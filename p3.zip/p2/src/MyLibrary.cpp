#include <MyLibrary.h>
#include <iostream>

using namespace std;

void hello(void)
{
    cout << "Moin aus der MyLibrary" << std::endl;
}