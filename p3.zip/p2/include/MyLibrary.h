#ifndef _MYLIBRARY_H_
#define _MYLIBRARY_H_


void hello();

#endif