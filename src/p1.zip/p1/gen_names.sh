#!/bin/bash
cd ./kexdir
touch KameronSimpson.pub
touch ManhaRedman.pub
touch AnnieHoward.pub
touch EmaanFry.pub
touch KieNavarro.pub
touch AnilBooth.pub
touch WinnieGamble.pub
touch JaydenSalt.pub
touch MacauleStrickland.pub
touch KhiaVang.pub